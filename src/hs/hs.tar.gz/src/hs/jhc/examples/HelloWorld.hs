
main = putStrLn "Hello, World!"
