
data Proxy a :: # = Proxy
